<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles.css">
	<title>JSON crud operations with php </title>
</head>
<body>
	<h1>JSON CRUD Application in php</h1>

	<?php include 'script.php'; ?>



</body>
</html>